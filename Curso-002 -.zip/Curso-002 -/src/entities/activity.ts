export interface Activity{
    name:string;
}