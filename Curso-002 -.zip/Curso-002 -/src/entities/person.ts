export interface Person{
    fullName:string;
    identification:number;
    mail:string;
    direction:string;
}