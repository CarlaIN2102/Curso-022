export interface GradeBookSetup{
    value:string;
    course:string;
    activity:string;
    topgrade:number;
}