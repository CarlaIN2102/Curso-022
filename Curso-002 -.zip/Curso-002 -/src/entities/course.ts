export interface Course {
    name:string;
}